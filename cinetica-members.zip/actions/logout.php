<?php

setcookie('logado', '', 1, '/');

header('Location: ../index.php');

echo 'thats all folks';

?>