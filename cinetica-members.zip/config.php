<?php

$host = "localhost";
$usuario = "root";
$senha = "";
$banco = "members";

$conexao = new mysqli($host, $usuario, $senha, $banco);

?>